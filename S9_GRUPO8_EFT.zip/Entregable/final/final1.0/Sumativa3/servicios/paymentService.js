import axios from "axios";
import { ACCESS_TOKEN } from "../config.js";

//en teoria se llamara a la api externa de mercado pago y se podria pagar y validar los pagos (en teoria marge! en teoria!)

export const createPayment = async (req, res) => {
  const url = "https://api.mercadopago.com/checkout/preferences";

  const { productos, user } = req.body;

  const body = {
    payer: user,
    items: productos,
    back_urls: {
      failure: "failure",
      pending: "pending",
      success: "success",
    },
    installments: 6
  };

  const payment = await axios.post(url, body, {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${ACCESS_TOKEN}`,
    },
  });

  return payment.data;
};
