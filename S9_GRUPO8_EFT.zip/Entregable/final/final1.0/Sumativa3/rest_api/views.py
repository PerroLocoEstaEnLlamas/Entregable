from django.shortcuts import render

# Create your views here.
#Contrucciòn del Rest
from rest_framework.response import Response
#Visualizaciòn del API Rest
from rest_framework.decorators import api_view
# Seguridad (Eliminar o activar)
from django.views.decorators.csrf import csrf_exempt
# Formato Json
from rest_framework.parsers import JSONParser
#libreria de còdigo de respuesta
from rest_framework import status

from core.models import Juego
from .serializers import JuegoSerializer


@csrf_exempt
@api_view (['GET', 'POST'])
def lista_juegos(request):
    if request.method == 'GET':
        juego = Juego.objects.all()
        serializer = JuegoSerializer(juego, many=True)
        
        return Response(serializer.data)

